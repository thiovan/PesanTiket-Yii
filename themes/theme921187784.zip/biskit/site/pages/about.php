<?php
$this->pageTitle=Yii::app()->name . ' - About';
$this->breadcrumbs=array(
	'About',
);
?>
<h1 class="art-postheader">About</h1>
<br />
<!-- add 3 line div -->
<div class="art-content-layout">
	<div class="art-content-layout-row">
		<div class="art-layout-cell layout-item-about" style="width: 100%;">
		
			<p>This is a "static" page. You may change the content of this page
			by updating the file <b><?php echo __FILE__; ?></b></p> <br />
			
			Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam pharetra, tellus sit amet congue vulputate, nisi erat iaculis nibh,
			vitae feugiat sapien ante eget mauris.Cras elit nisl, rhoncus nec iaculis ultricies, feugiat eget sapien.
			Pellentesque ac felis tellus. Aenean sollicitudin imperdiet arcu, vitae dignissim est posuere id. Duis placerat justo eu nunc interdum ultrices.
		</div>
	</div>
</div>